# -*- coding: utf-8 -*-

CHECKBOX_RSC = "{ro} {sta} {capt} {shCut}"
RADIOBTN_RSC = "{ro} {sta} {capt} {shCut}"
CHECKMENU_RSC = "{sta} {capt} {shCut}"
RADIOMENU_RSC = "{ro} {sta} {capt} {shCut}"
	
	